//
//  ViewController.swift
//  weatherTravel
//
//  Created by Grace Choe on 2/25/18.
//  Copyright © 2018 Grace Choe. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var lowTemp: String = ""
    var returnStr: String = ""
    
    @IBOutlet weak var lowTempText: UITextField!
    @IBOutlet weak var highTempField: UITextField!
    @IBOutlet weak var searchOutput: UILabel!
    
    @IBOutlet weak var monthLabel: UILabel!
    @IBAction func monthStepper(_ sender: UIStepper) {
        monthLabel.text = String(Int(sender.value))
    }
    
    @IBAction func displayInput(_ sender: UIButton) {
        self.getJsonFromUrl(completion: self.showNames)
    }
    


    var infoDict = [String:[Double]]()
    
    var cityDict = ["Seoul":[37.5663491,126.999731],"Tokyo":[35.68501691,139.7514074],"Istanbul":[41.10499615,29.01000159],
        "Kuala Lumpur":[3.166665872,101.6999833],"Singapore":[1.293033466,103.8558207],"New York":[40.74997906,-73.98001693],
        "Dubai":[25.22999615,55.27997432],"Paris":[48.86669293,2.333335326],"London":[42.9699986,-81.24998661],"Bangkok":[13.74999921,100.5166447]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //getJsonFromUrl()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getJsonFromUrl(completion: @escaping () -> Void){
        var monthVal = ""
        if monthLabel.text?.count == 1{
            monthVal = "0" + monthLabel.text!
        } else {
            monthVal = monthLabel.text!
        }
        let month: String = monthVal
        
        for (key, value) in self.cityDict {
            let myURL = "https://api.darksky.net/forecast/be71e2ac83119c780997fb9ac069f019/" + String(value[0]) + "," + String(value[1]) + ",2017-"+month + "-15T12:00:00"
            print(myURL)
            let url = NSURL(string: myURL)
            //fetching the data from the url
            URLSession.shared.dataTask(with: (url as? URL)!, completionHandler: {(data, response, error) -> Void in
                
                if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSDictionary {
                    //printing the json in console
                    
                    let outerDict = jsonObj!.value(forKey:"daily") as! NSDictionary
                    let innerList = outerDict.value(forKey:"data") as! NSArray
                    let innerDict = innerList[0] as! NSDictionary
                    let minTemp = innerDict.value(forKey:"temperatureMin") as! Double
                    let maxTemp = innerDict.value(forKey:"temperatureMax") as! Double
                    
                    self.infoDict[key] = [minTemp, maxTemp]
                    
                }
            }).resume()
        }

        completion()
        }
    
    func showNames(){
        var outStr = ""
        if let lowT = Double(lowTempText.text!), let highT = Double(highTempField.text!) {
                for (key,value) in self.infoDict{
                    if value[0] >= lowT && value[1] <= highT{
                        print(key, value)
                        outStr += String(key) + "\n"
                    }
            }
            searchOutput.text = outStr
            //showButtons()
        }
        
        }
    

}

